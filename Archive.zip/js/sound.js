////////////////////////////////////////////////////////////
// SOUND
////////////////////////////////////////////////////////////
const enableDesktopAudio = true; //audio for dekstop
const enableMobileAudio = true; //audio for mobile and tablet

const muteSoundOn = false; //mute sound
const muteMusicOn = false; //mute music

var audioOn;
var soundMute = false;
var musicMute = false;

$.sound = {};
var soundID = 0;
var soundPushArr = [];
var soundLoopPushArr = [];
var musicPushArr = [];

function playSound(soundName, vol){
	if(audioOn){
		var thisSoundID = soundID;
		soundPushArr.push(thisSoundID);
		soundID++;

		var defaultVol = vol == undefined ? 1 : vol;
		$.sound[thisSoundID] = createjs.Sound.play(soundName);
		$.sound[thisSoundID].defaultVol = defaultVol;
		setSoundVolume(thisSoundID);
		
		$.sound[thisSoundID].removeAllEventListeners();
		$.sound[thisSoundID].addEventListener ("complete", function() {
			var removeSoundIndex = soundPushArr.indexOf(thisSoundID);
			if(removeSoundIndex != -1){
				soundPushArr.splice(removeSoundIndex, 1);
			}
		});
	}
}

function playSoundLoop(soundName){
	if(audioOn){
		if($.sound[soundName]==null){
			soundLoopPushArr.push(soundName);

			$.sound[soundName] = createjs.Sound.play(soundName);
			$.sound[soundName].defaultVol = 1;
			setSoundLoopVolume(soundName);

			$.sound[soundName].removeAllEventListeners();
			$.sound[soundName].addEventListener ("complete", function() {
				$.sound[soundName].play();
			});
		}
	}
}

function toggleSoundLoop(soundName, con){
	if(audioOn){
		if($.sound[soundName]!=null){
			if(con){
				$.sound[soundName].play();
			}else{
				$.sound[soundName].paused = true;
			}
		}
	}
}

function stopSoundLoop(soundName){
	if(audioOn){
		if($.sound[soundName]!=null){
			$.sound[soundName].stop();
			$.sound[soundName]=null;

			var soundLoopIndex = soundLoopPushArr.indexOf(soundName);
			if(soundLoopIndex != -1){
				soundLoopPushArr.splice(soundLoopIndex, 1);
			}
		}
	}
}

function playMusicLoop(soundName){
	if(audioOn){
		if($.sound[soundName]==null){
			musicPushArr.push(soundName);

			$.sound[soundName] = createjs.Sound.play(soundName);
			$.sound[soundName].defaultVol = 1;
			setMusicVolume(soundName);

			$.sound[soundName].removeAllEventListeners();
			$.sound[soundName].addEventListener ("complete", function() {
				$.sound[soundName].play();
			});
		}
	}
}

function toggleMusicLoop(soundName, con){
	if(audioOn){
		if($.sound[soundName]!=null){
			if(con){
				$.sound[soundName].play();
			}else{
				$.sound[soundName].paused = true;
			}
		}
	}
}

function stopMusicLoop(soundName){
	if(audioOn){
		if($.sound[soundName]!=null){
			$.sound[soundName].stop();
			$.sound[soundName]=null;

			var soundLoopIndex = musicPushArr.indexOf(soundName);
			if(soundLoopIndex != -1){
				musicPushArr.splice(soundLoopIndex, 1);
			}
		}
	}
}

function stopSound(){
	createjs.Sound.stop();
}

function toggleSoundInMute(con){
	if(audioOn){
		soundMute = con;
		for(var n=0; n<soundPushArr.length; n++){
			setSoundVolume(soundPushArr[n]);
		}
		for(var n=0; n<soundLoopPushArr.length; n++){
			setSoundLoopVolume(soundLoopPushArr[n]);
		}
	}
}

function toggleMusicInMute(con){
	if(audioOn){
		musicMute = con;
		for(var n=0; n<musicPushArr.length; n++){
			setMusicVolume(musicPushArr[n]);
		}
	}
}

function setSoundVolume(id, vol){
	if(audioOn){
		var soundIndex = soundPushArr.indexOf(id);
		if(soundIndex != -1){
			var defaultVol = vol == undefined ? $.sound[soundPushArr[soundIndex]].defaultVol : vol;
			var volume = soundMute == false ? defaultVol : 0;
			$.sound[soundPushArr[soundIndex]].volume = volume;
			$.sound[soundPushArr[soundIndex]].defaultVol = defaultVol;
		}
	}
}

function setSoundLoopVolume(soundLoop, vol){
	if(audioOn){
		var soundLoopIndex = soundLoopPushArr.indexOf(soundLoop);
		if(soundLoopIndex != -1){
			var defaultVol = vol == undefined ? $.sound[soundLoopPushArr[soundLoopIndex]].defaultVol : vol;
			var volume = soundMute == false ? defaultVol : 0;
			$.sound[soundLoopPushArr[soundLoopIndex]].volume = volume;
			$.sound[soundLoopPushArr[soundLoopIndex]].defaultVol = defaultVol;
		}
	}
}

function setMusicVolume(soundLoop, vol){
	if(audioOn){
		var musicIndex = musicPushArr.indexOf(soundLoop);
		if(musicIndex != -1){
			var defaultVol = vol == undefined ? $.sound[musicPushArr[musicIndex]].defaultVol : vol;
			var volume = musicMute == false ? defaultVol : 0;
			$.sound[musicPushArr[musicIndex]].volume = volume;
			$.sound[musicPushArr[musicIndex]].defaultVol = defaultVol;
		}
	}
}

/*!
 * 
 * MISC - This is the function that runs to play misc audio
 * 
 */

function playSoundID(soundName, callback){
	if(audioOn){
		if($.sound[soundName]==null){
			soundPushArr.push(soundName);

			$.sound[soundName] = createjs.Sound.play(soundName);
			$.sound[soundName].defaultVol = 1;
			setSoundVolume(soundName);

			$.sound[soundName].removeAllEventListeners();
			if(callback != undefined)
				$.sound[soundName].addEventListener ("complete", callback);
		}
	}
}

function stopSoundID(soundName){
	if(audioOn){
		if($.sound[soundName]!=null){
			$.sound[soundName].stop();
			$.sound[soundName]=null;

			var soundIndex = soundPushArr.indexOf(soundName);
			if(soundIndex != -1){
				soundPushArr.splice(soundIndex, 1);
			}
		}
	}
}